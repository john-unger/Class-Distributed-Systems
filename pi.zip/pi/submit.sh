#!/bin/bash
#SBATCH --job-name=chapel
#SBATCH --nodes=1
#SBATCH --ntasks=8

./run.sh

